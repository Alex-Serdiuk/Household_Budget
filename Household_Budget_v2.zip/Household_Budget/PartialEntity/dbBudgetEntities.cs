﻿using Household_Budget;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Household_Budget
{
    public partial class DbBudgetEntities : DbContext
    {

        public DbBudgetEntities()
        : base("name=DbBudgetEntities")
        {

        }
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            throw new UnintentionalCodeFirstException();
        }

        public virtual DbSet<Article> Article { get; set; }

        public virtual DbSet<ExpenditureName> ExpenditureName { get; set; }

        public virtual DbSet<ExpenditureType> ExpenditureType { get; set; }

        public virtual DbSet<IncomeSource> IncomeSource { get; set; }

    }
}
