﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Household_Budget
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static MainWindow MainView; //Статичне посилання на головне вікно

        private AllExpensesView expensesView;
        public MainWindow()
        {
            MainView = this;
            InitializeComponent();

            ExpensesViewModePicker.SelectedIndex = 0;

            UpdateView();
        }

        public void UpdateView()
        {
            using(dbBudgetEntities db =  new dbBudgetEntities())
            {

            }
        }

        private void ExpensesViewModePicker_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            showExpenses();
        }

        //Вызов формы показа расходов/доходов
        private void showExpenses()
        {
            MainExpensesPanel.Children.Remove(expensesView);

            Binding b = new Binding("SelectedDate");
            b.Source = ExpensesCurrentDate;
            b.Mode = BindingMode.TwoWay;

            expensesView = new AllExpensesView();
            expensesView.SetBinding(AllExpensesView.CurrentDateProperty, b);

            switch (ExpensesViewModePicker.SelectedIndex)
            {
                case 0:
                    break;
                case 1:
                    expensesView.Mode = "day";
                    break;
                case 2:
                    expensesView.Mode = "week";
                    break;
                case 3:
                    expensesView.Mode = "month";
                    break;
            }

            Grid.SetRow(expensesView, 1);
            Grid.SetColumnSpan(expensesView, 4);
            MainExpensesPanel.Children.Add(expensesView);
        }

        private void NewIncome_Click(object sender, RoutedEventArgs e)
        {
            Income income = new Income() { DateTime = DateTime.Now };
            RecordWindow window = income.GetEditWindow();
            if (window.ShowDialog() == true)
                showExpenses();
        }
    }
}
